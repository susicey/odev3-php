<?php


$urun_adi = $_POST['urun_adi'] ?? '';
$fiyat = $_POST['fiyat'] ?? '';
$adet = $_POST['adet'] ?? '';
$kdv = $_POST['kdv'] ?? '';
$indirim_kodu = $_POST['indirim'] ?? '';


if (empty($urun_adi) || empty($fiyat) || empty($adet) || empty($kdv)) {
    echo "<p style='color:red;'>Lütfen zorunlu alanları doldurun</p>";
    exit;
}


$fiyat = (float)$fiyat;
$adet = (int)$adet;
$kdv = (float)$kdv;


if ($kdv < 20) {
    echo "<p style='color:red;'>KDV oranı en az %20 olmalıdır</p>";
    exit;
}

$ara_toplam = $fiyat * $adet;


$kdv_tutar = $ara_toplam * ($kdv / 100);
$indirim_oran = 0;

if ($indirim_kodu == "IND20") {
    $indirim_oran = 20;
} 
else if ($indirim_kodu == "IND50") {
    $indirim_oran = 50;
}

$indirim_tutar = $ara_toplam * ($indirim_oran / 100);

$genel_toplam = $ara_toplam + $kdv_tutar - $indirim_tutar;

echo "<h2>$urun_adi için toplam tutar</h2>";

echo "<p>Birim Fiyat: $fiyat TL</p>";
echo "<p>Adet: $adet</p>";

echo "<p>Ara Toplam: $ara_toplam TL</p>";
echo "<p>KDV Tutarı: $kdv_tutar TL</p>";

if ($indirim_oran > 0) {
    echo "<p>'$indirim_kodu' kodu uygulandı - İndirim: $indirim_tutar TL</p>";
} else {
    echo "<p>İndirim uygulanmadı</p>";
}

echo "<h3>Genel Toplam: $genel_toplam TL</h3>";


?>