<?php

$username = $_POST['username'] ?? '';
$password = $_POST['password'] ?? '';

if (empty($username) || empty($password)) {
    echo "<p style='color:red;'>Lütfen tüm alanları doldurun</p>";
}

else if ($username == "admin" && $password == "1234") {
    echo "<p style='color:green;'>Giriş başarılı, hoş geldiniz admin</p>";
}

else {
    echo "<p style='color:red;'>Kullanıcı adı veya şifre hatalı</p>";
}

?>